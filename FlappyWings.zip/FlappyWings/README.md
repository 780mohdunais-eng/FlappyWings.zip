# Flappy Wings

A Flappy Bird-inspired game with coins, unlockable birds, customization,
daily missions, and a daily reward wheel.

## What's fully real

- Tap-to-fly physics, pipes, collisions, scoring — a real Canvas/SurfaceView
  game loop (`GameView.kt`), the standard reliable way to build 2D Android
  games.
- Coins: +1 per pipe crossed, spent in the shop.
- 5 birds (Normal free, Red 500, Blue 1000, Black 2000, Golden 5000) — same
  physics for all, only color differs, as specified.
- Customization: Glasses, Hat, Crown — bought with coins, equipped/unequipped
  from the shop, drawn on the bird in-game.
- Daily mission: one random mission per day (cross 20 pipes / collect 30
  coins / play 5 games), 150-200 coin reward, resets at midnight.
- Daily spin wheel: one free spin every 24 hours, coins or items as reward.
- Difficulty ramps up with score (pipe gap shrinks, speed rises, both capped
  so it stays fair).
- All progress saved locally (SharedPreferences) — survives app restarts.

## What's simplified (and why)

- **Bird/item art is vector-drawn (XML shapes), not PNG artwork.** There's no
  image-generation tool available here, and using real bird sprite images
  would mean either downloading copyrighted game art (not okay) or stock
  photos that wouldn't fit a cartoon game anyway. The vector birds are an
  original simple flat-design (body/wing/belly/eye/beak as separate shapes) —
  a genuine tradeoff, not a placeholder; if you'd rather use real PNGs later,
  drop them into `res/drawable/` with matching names
  (`bird_normal.png` etc.) and remove the `.xml` versions.
- **Sound effects are synthesized tones** (`SoundManager.kt` generates simple
  beeps in code), not recorded sound files. There's **no background music** —
  that needs an actual audio file, which isn't something I can produce here.
  To add music: drop an mp3 into `res/raw/bg_music.mp3` and wire up a
  `MediaPlayer` in `GameActivity`.
- **"Watch Ad to Continue" is a simulated placeholder** (a short delay, then
  it just continues you and gives bonus coins) — real ads need an AdMob
  account and ad unit IDs, which requires you to set up your own Google ad
  account; this button is wired so real AdMob SDK calls can be dropped in
  later without changing the surrounding game logic.

## Setup

Same as the other projects: open in Android Studio (API 26+), or zip → GitHub
Actions → `./gradlew assembleDebug` → download the APK from Artifacts.

## Tuning

- Physics constants (gravity, flap strength, pipe speed/gap, difficulty ramp):
  top of `GameView.kt`.
- Mission types/targets/rewards: `MissionType` enum in `GameData.kt`.
- Shop prices: `Catalog` object in `GameData.kt`.
- Spin wheel rewards: `segments` list in `SpinWheelView.kt` +
  `applyReward()` in `DailyRewardActivity.kt`.
