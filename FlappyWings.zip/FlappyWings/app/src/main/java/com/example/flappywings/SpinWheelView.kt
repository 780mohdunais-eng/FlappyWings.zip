package com.example.flappywings

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.cos
import kotlin.math.sin

class SpinWheelView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    data class Segment(val label: String, val color: Int)

    val segments = listOf(
        Segment("50", Color.parseColor("#FFC93C")),
        Segment("Glasses", Color.parseColor("#3FA9F5")),
        Segment("100", Color.parseColor("#FF5B4F")),
        Segment("Hat", Color.parseColor("#5EC25A")),
        Segment("200", Color.parseColor("#B455FF")),
        Segment("500", Color.parseColor("#FFD700"))
    )

    private var rotation = 0f
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 32f; textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    private val pointerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val radius = minOf(width, height) / 2f - 12f
        val rect = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
        val sweep = 360f / segments.size

        canvas.save()
        canvas.rotate(rotation, cx, cy)
        for (i in segments.indices) {
            arcPaint.color = segments[i].color
            canvas.drawArc(rect, i * sweep, sweep, true, arcPaint)
        }
        for (i in segments.indices) {
            val mid = Math.toRadians((i * sweep + sweep / 2).toDouble())
            val tx = cx + (radius * 0.65f) * cos(mid).toFloat()
            val ty = cy + (radius * 0.65f) * sin(mid).toFloat()
            canvas.save()
            canvas.rotate(i * sweep + sweep / 2, tx, ty)
            canvas.drawText(segments[i].label, tx, ty, textPaint)
            canvas.restore()
        }
        canvas.restore()

        val path = Path()
        path.moveTo(cx - 14f, cy - radius - 4f)
        path.lineTo(cx + 14f, cy - radius - 4f)
        path.lineTo(cx, cy - radius + 24f)
        path.close()
        canvas.drawPath(path, pointerPaint)
    }

    fun spinTo(targetIndex: Int, onDone: () -> Unit) {
        val sweep = 360f / segments.size
        val base = rotation - (rotation % 360f)
        val targetAngle = base + 360f * 6 + (360f - (targetIndex * sweep + sweep / 2f))
        val anim = ValueAnimator.ofFloat(rotation, targetAngle)
        anim.duration = 3200
        anim.interpolator = DecelerateInterpolator(2.2f)
        anim.addUpdateListener {
            rotation = it.animatedValue as Float
            invalidate()
        }
        anim.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { onDone() }
        })
        anim.start()
    }
}
