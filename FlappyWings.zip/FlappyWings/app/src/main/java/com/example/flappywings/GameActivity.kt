package com.example.flappywings

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class GameActivity : AppCompatActivity(), GameListener {

    private lateinit var gameView: GameView
    private var adUsedThisGame = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        gameView = findViewById(R.id.gameView)
        gameView.listener = this

        gameView.setOnClickListener { gameView.flap() }

        findViewById<Button>(R.id.btnRestart).setOnClickListener {
            findViewById<android.view.View>(R.id.gameOverCard).visibility = android.view.View.GONE
            adUsedThisGame = false
            gameView.restart()
        }

        findViewById<Button>(R.id.btnHome).setOnClickListener { finish() }

        findViewById<Button>(R.id.btnWatchAd).setOnClickListener {
            if (adUsedThisGame) {
                Toast.makeText(this, "You can only continue once", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            it.isEnabled = false
            Toast.makeText(this, "Ad playing... (simulated)", Toast.LENGTH_SHORT).show()
            Handler(Looper.getMainLooper()).postDelayed({
                adUsedThisGame = true
                findViewById<android.view.View>(R.id.gameOverCard).visibility = android.view.View.GONE
                GameData.addCoins(this, 20)
                gameView.continueAfterAd()
            }, 1500)
        }
    }

    override fun onGameOver(score: Int, coinsEarned: Int) {
        runOnUiThread {
            findViewById<TextView>(R.id.scoreText).text = "Score: $score"
            findViewById<TextView>(R.id.coinsText).text = "Coins earned: +$coinsEarned"
            findViewById<TextView>(R.id.bestText).text = "Best: ${GameData.getHighScore(this)}"
            findViewById<Button>(R.id.btnWatchAd).isEnabled = true
            findViewById<android.view.View>(R.id.gameOverCard).visibility = android.view.View.VISIBLE
        }
    }

    override fun onScoreChanged(score: Int, coins: Int) {}

    override fun onResume() {
        super.onResume()
        gameView.loadBirdAppearance()
    }
}
