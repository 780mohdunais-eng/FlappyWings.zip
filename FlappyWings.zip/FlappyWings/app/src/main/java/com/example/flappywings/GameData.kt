package com.example.flappywings

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

data class Bird(val id: String, val name: String, val cost: Int, val drawable: String)
data class ShopItem(val id: String, val name: String, val cost: Int, val drawable: String, val slot: String)

object Catalog {
    val birds = listOf(
        Bird("bird_normal", "Normal Bird", 0, "bird_normal"),
        Bird("bird_red", "Red Bird", 500, "bird_red"),
        Bird("bird_blue", "Blue Bird", 1000, "bird_blue"),
        Bird("bird_black", "Black Bird", 2000, "bird_black"),
        Bird("bird_golden", "Golden Bird", 5000, "bird_golden")
    )
    val items = listOf(
        ShopItem("item_glasses", "Glasses", 300, "item_glasses", "face"),
        ShopItem("item_hat", "Hat", 400, "item_hat", "head"),
        ShopItem("item_crown", "Crown", 800, "item_crown", "head")
    )
}

enum class MissionType(val target: Int, val reward: Int, val label: String) {
    CROSS_PIPES(20, 180, "20 Pipes cross karo"),
    COLLECT_COINS(30, 150, "30 Coins collect karo"),
    PLAY_GAMES(5, 200, "5 Games khelo")
}

object GameData {

    private const val PREFS = "flappy_prefs"
    private lateinit var prefsRef: android.content.SharedPreferences

    private fun prefs(context: Context): android.content.SharedPreferences {
        if (!::prefsRef.isInitialized) prefsRef = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefsRef
    }

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    // ---------- coins & score ----------
    fun getCoins(context: Context) = prefs(context).getInt("coins", 0)
    fun addCoins(context: Context, amount: Int) {
        prefs(context).edit().putInt("coins", getCoins(context) + amount).apply()
        addTodayCoins(context, amount)
    }
    fun spendCoins(context: Context, amount: Int): Boolean {
        val c = getCoins(context)
        if (c < amount) return false
        prefs(context).edit().putInt("coins", c - amount).apply()
        return true
    }

    fun getHighScore(context: Context) = prefs(context).getInt("high_score", 0)
    fun updateHighScore(context: Context, score: Int) {
        if (score > getHighScore(context)) prefs(context).edit().putInt("high_score", score).apply()
    }

    // ---------- ownership & selection ----------
    fun ownsBird(context: Context, id: String) = id == "bird_normal" || prefs(context).getStringSet("owned_birds", setOf())!!.contains(id)
    fun unlockBird(context: Context, id: String) {
        val set = prefs(context).getStringSet("owned_birds", setOf())!!.toMutableSet()
        set.add(id)
        prefs(context).edit().putStringSet("owned_birds", set).apply()
    }
    fun getSelectedBird(context: Context) = prefs(context).getString("selected_bird", "bird_normal") ?: "bird_normal"
    fun selectBird(context: Context, id: String) = prefs(context).edit().putString("selected_bird", id).apply()

    fun ownsItem(context: Context, id: String) = prefs(context).getStringSet("owned_items", setOf())!!.contains(id)
    fun unlockItem(context: Context, id: String) {
        val set = prefs(context).getStringSet("owned_items", setOf())!!.toMutableSet()
        set.add(id)
        prefs(context).edit().putStringSet("owned_items", set).apply()
    }
    fun getEquipped(context: Context, slot: String) = prefs(context).getString("equipped_$slot", "") ?: ""
    fun setEquipped(context: Context, slot: String, id: String) = prefs(context).edit().putString("equipped_$slot", id).apply()

    // ---------- daily mission ----------
    fun getTodayMission(context: Context): Pair<MissionType, Int> {
        val p = prefs(context)
        val storedDate = p.getString("mission_date", "")
        if (storedDate != today()) {
            val type = MissionType.entries.random()
            p.edit()
                .putString("mission_date", today())
                .putString("mission_type", type.name)
                .putInt("mission_progress", 0)
                .putBoolean("mission_claimed", false)
                .putInt("today_coins", 0)
                .putInt("today_games", 0)
                .apply()
            return type to 0
        }
        val type = MissionType.valueOf(p.getString("mission_type", MissionType.CROSS_PIPES.name)!!)
        return type to p.getInt("mission_progress", 0)
    }

    fun isMissionClaimed(context: Context) = prefs(context).getBoolean("mission_claimed", false)
    fun claimMission(context: Context) {
        prefs(context).edit().putBoolean("mission_claimed", true).apply()
    }

    private fun addTodayCoins(context: Context, amount: Int) {
        getTodayMission(context) // ensures date rollover happened
        val p = prefs(context)
        p.edit().putInt("today_coins", p.getInt("today_coins", 0) + amount).apply()
        bumpMissionProgress(context, MissionType.COLLECT_COINS, p.getInt("today_coins", 0))
    }

    fun addPipeCrossed(context: Context, totalThisRun: Int) {
        getTodayMission(context)
        bumpMissionProgress(context, MissionType.CROSS_PIPES, totalThisRun)
    }

    fun addGamePlayed(context: Context) {
        getTodayMission(context)
        val p = prefs(context)
        val games = p.getInt("today_games", 0) + 1
        p.edit().putInt("today_games", games).apply()
        bumpMissionProgress(context, MissionType.PLAY_GAMES, games)
    }

    private fun bumpMissionProgress(context: Context, relevantType: MissionType, newValue: Int) {
        val p = prefs(context)
        val currentType = MissionType.valueOf(p.getString("mission_type", MissionType.CROSS_PIPES.name)!!)
        if (currentType != relevantType) return
        val current = p.getInt("mission_progress", 0)
        if (newValue > current) p.edit().putInt("mission_progress", newValue.coerceAtMost(currentType.target)).apply()
    }

    // ---------- daily spin wheel ----------
    fun canSpinToday(context: Context): Boolean {
        val last = prefs(context).getLong("last_spin", 0L)
        return System.currentTimeMillis() - last >= 24 * 60 * 60 * 1000L
    }
    fun recordSpin(context: Context) {
        prefs(context).edit().putLong("last_spin", System.currentTimeMillis()).apply()
    }
    fun spinTimeRemainingMs(context: Context): Long {
        val last = prefs(context).getLong("last_spin", 0L)
        val remain = 24 * 60 * 60 * 1000L - (System.currentTimeMillis() - last)
        return remain.coerceAtLeast(0)
    }

    // ---------- settings ----------
    fun isSoundOn(context: Context) = prefs(context).getBoolean("sound_on", true)
    fun setSoundOn(context: Context, v: Boolean) = prefs(context).edit().putBoolean("sound_on", v).apply()
}
