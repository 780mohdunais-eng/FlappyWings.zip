package com.example.flappywings

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnPlay).setOnClickListener {
            startActivity(Intent(this, GameActivity::class.java))
        }
        findViewById<Button>(R.id.btnShop).setOnClickListener {
            startActivity(Intent(this, ShopActivity::class.java))
        }
        findViewById<Button>(R.id.btnDailyReward).setOnClickListener {
            startActivity(Intent(this, DailyRewardActivity::class.java))
        }

        val soundSwitch = findViewById<Switch>(R.id.soundSwitch)
        soundSwitch.isChecked = GameData.isSoundOn(this)
        soundSwitch.setOnCheckedChangeListener { _, checked -> GameData.setSoundOn(this, checked) }

        findViewById<Button>(R.id.btnClaimMission).setOnClickListener {
            val (type, progress) = GameData.getTodayMission(this)
            if (GameData.isMissionClaimed(this)) {
                Toast.makeText(this, "Aaj ka mission already claim ho chuka hai", Toast.LENGTH_SHORT).show()
            } else if (progress >= type.target) {
                GameData.addCoins(this, type.reward)
                GameData.claimMission(this)
                Toast.makeText(this, "+${type.reward} coins mile!", Toast.LENGTH_SHORT).show()
                refresh()
            } else {
                Toast.makeText(this, "Pehle mission complete karo", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        findViewById<TextView>(R.id.coinsText).text = "🪙 ${GameData.getCoins(this)} Coins"
        findViewById<TextView>(R.id.bestText).text = "Best Score: ${GameData.getHighScore(this)}"

        val (type, progress) = GameData.getTodayMission(this)
        val claimed = GameData.isMissionClaimed(this)
        findViewById<TextView>(R.id.missionText).text =
            "${type.label}  ($progress/${type.target})" + if (claimed) " ✅" else ""
        findViewById<ProgressBar>(R.id.missionProgress).apply {
            max = type.target
            progress2(progress)
        }
        findViewById<Button>(R.id.btnClaimMission).apply {
            isEnabled = !claimed && progress >= type.target
            text = if (claimed) "Claimed" else "Claim Reward (+${type.reward})"
        }
    }

    private fun ProgressBar.progress2(v: Int) { this.progress = v }
}
