package com.example.flappywings

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ShopActivity : AppCompatActivity() {

    private lateinit var birdsContainer: android.widget.LinearLayout
    private lateinit var itemsContainer: android.widget.LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shop)

        birdsContainer = findViewById(R.id.birdsContainer)
        itemsContainer = findViewById(R.id.itemsContainer)

        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }

        refresh()
    }

    private fun refresh() {
        findViewById<TextView>(R.id.coinsText).text = "🪙 ${GameData.getCoins(this)} Coins"
        birdsContainer.removeAllViews()
        itemsContainer.removeAllViews()

        for (bird in Catalog.birds) {
            val row = LayoutInflater.from(this).inflate(R.layout.item_shop_row, birdsContainer, false)
            bindBirdRow(row, bird)
            birdsContainer.addView(row)
        }

        for (item in Catalog.items) {
            val row = LayoutInflater.from(this).inflate(R.layout.item_shop_row, itemsContainer, false)
            bindItemRow(row, item)
            itemsContainer.addView(row)
        }
    }

    private fun bindBirdRow(row: android.view.View, bird: Bird) {
        val icon = row.findViewById<ImageView>(R.id.icon)
        val name = row.findViewById<TextView>(R.id.name)
        val btn = row.findViewById<Button>(R.id.actionBtn)

        val resId = resources.getIdentifier(bird.drawable, "drawable", packageName)
        if (resId != 0) icon.setImageResource(resId)

        val owned = GameData.ownsBird(this, bird.id)
        val selected = GameData.getSelectedBird(this) == bird.id

        name.text = if (bird.cost == 0) bird.name else "${bird.name} — ${bird.cost} coins"

        when {
            selected -> { btn.text = "Selected"; btn.isEnabled = false }
            owned -> {
                btn.text = "Select"
                btn.isEnabled = true
                btn.setOnClickListener {
                    GameData.selectBird(this, bird.id)
                    refresh()
                }
            }
            else -> {
                btn.text = "Buy"
                btn.isEnabled = true
                btn.setOnClickListener {
                    if (GameData.spendCoins(this, bird.cost)) {
                        GameData.unlockBird(this, bird.id)
                        GameData.selectBird(this, bird.id)
                        Toast.makeText(this, "${bird.name} unlocked!", Toast.LENGTH_SHORT).show()
                        refresh()
                    } else {
                        Toast.makeText(this, "Not enough coins", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun bindItemRow(row: android.view.View, item: ShopItem) {
        val icon = row.findViewById<ImageView>(R.id.icon)
        val name = row.findViewById<TextView>(R.id.name)
        val btn = row.findViewById<Button>(R.id.actionBtn)

        val resId = resources.getIdentifier(item.drawable, "drawable", packageName)
        if (resId != 0) icon.setImageResource(resId)

        val owned = GameData.ownsItem(this, item.id)
        val equipped = GameData.getEquipped(this, item.slot) == item.id

        name.text = "${item.name} — ${item.cost} coins"

        when {
            equipped -> {
                btn.text = "Unequip"
                btn.isEnabled = true
                btn.setOnClickListener {
                    GameData.setEquipped(this, item.slot, "")
                    refresh()
                }
            }
            owned -> {
                btn.text = "Equip"
                btn.isEnabled = true
                btn.setOnClickListener {
                    GameData.setEquipped(this, item.slot, item.id)
                    refresh()
                }
            }
            else -> {
                btn.text = "Buy"
                btn.isEnabled = true
                btn.setOnClickListener {
                    if (GameData.spendCoins(this, item.cost)) {
                        GameData.unlockItem(this, item.id)
                        GameData.setEquipped(this, item.slot, item.id)
                        Toast.makeText(this, "${item.name} unlocked!", Toast.LENGTH_SHORT).show()
                        refresh()
                    } else {
                        Toast.makeText(this, "Not enough coins", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}
