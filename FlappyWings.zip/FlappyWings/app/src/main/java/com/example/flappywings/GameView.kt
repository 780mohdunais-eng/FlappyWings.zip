package com.example.flappywings

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import androidx.core.content.ContextCompat
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

interface GameListener {
    fun onGameOver(score: Int, coinsEarned: Int)
    fun onScoreChanged(score: Int, coins: Int)
}

class GameView(context: Context, attrs: AttributeSet? = null) :
    SurfaceView(context, attrs), SurfaceHolder.Callback {

    private var thread: Thread? = null
    @Volatile private var running = false

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    // ---- physics ----
    private var birdY = 0f
    private var birdVelocity = 0f
    private val gravity = dp(1500f)
    private val flapVelocity = -dp(520f)
    private val maxFall = dp(900f)
    private var birdX = 0f
    private val birdRadius = dp(20f)

    // ---- pipes ----
    data class Pipe(var x: Float, val gapCenter: Float, val gapSize: Float, var scored: Boolean = false)
    private val pipes = mutableListOf<Pipe>()
    private val pipeWidth = dp(76f)
    private var pipeSpeed = dp(150f)
    private var gapSize = dp(285f)
    private var distanceSinceLastPipe = 0f
    private val pipeSpacing = dp(300f)

    private var groundHeight = dp(60f)
    private var groundOffset = 0f

    private var score = 0
    private var coinsThisRun = 0
    private var gameOver = false
    private var started = false

    var listener: GameListener? = null

    // ---- drawables ----
    private var birdDrawable: Drawable? = null
    private var headAccessory: Drawable? = null
    private var faceAccessory: Drawable? = null

    private val skyPaint = Paint()
    private val dirtPaint = Paint().apply { color = Color.parseColor("#8B5E34") }
    private val soilLinePaint = Paint().apply { color = Color.argb(45, 0, 0, 0) }
    private val grassPaint = Paint().apply { color = Color.parseColor("#5EC25A") }
    private val grassShadePaint = Paint().apply { color = Color.parseColor("#4AA047") }
    private val woodGrainPaint = Paint().apply { color = Color.argb(80, 0, 0, 0); strokeWidth = dp(2f) }
    private val woodCapPaint = Paint().apply { color = Color.parseColor("#D8B98A") }
    private val woodCapEdgePaint = Paint().apply {
        color = Color.parseColor("#8B5E34"); style = Paint.Style.STROKE; strokeWidth = dp(2f)
    }
    private val woodRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B08A5E"); style = Paint.Style.STROKE; strokeWidth = dp(1.5f)
    }
    private val pipePaint = Paint()
    private val pipeEdgePaint = Paint().apply {
        color = Color.argb(60, 0, 0, 0); style = Paint.Style.STROKE; strokeWidth = dp(3f)
    }
    private val scorePaint = Paint().apply {
        color = Color.WHITE; textSize = dp(36f); textAlign = Paint.Align.CENTER
        setShadowLayer(6f, 0f, 3f, Color.BLACK); isFakeBoldText = true
    }

    init {
        holder.addCallback(this)
        isFocusable = true
        loadBirdAppearance()
    }

    fun loadBirdAppearance() {
        val birdId = GameData.getSelectedBird(context)
        val resId = resources.getIdentifier(birdId, "drawable", context.packageName)
        birdDrawable = if (resId != 0) ContextCompat.getDrawable(context, resId) else null

        val head = GameData.getEquipped(context, "head")
        headAccessory = if (head.isNotBlank()) {
            val id = resources.getIdentifier(head, "drawable", context.packageName)
            if (id != 0) ContextCompat.getDrawable(context, id) else null
        } else null

        val face = GameData.getEquipped(context, "face")
        faceAccessory = if (face.isNotBlank()) {
            val id = resources.getIdentifier(face, "drawable", context.packageName)
            if (id != 0) ContextCompat.getDrawable(context, id) else null
        } else null
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        resetGame()
        running = true
        thread = Thread { gameLoop() }.also { it.start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        thread?.join()
        thread = null
    }

    fun restart() {
        resetGame()
    }

    fun continueAfterAd() {
        gameOver = false
        pipes.clear()
        distanceSinceLastPipe = 0f
        birdY = height * 0.4f
        birdVelocity = 0f
    }

    private fun resetGame() {
        birdX = width * 0.28f
        birdY = height * 0.4f
        birdVelocity = 0f
        pipes.clear()
        score = 0
        coinsThisRun = 0
        gameOver = false
        started = false
        pipeSpeed = dp(150f)
        gapSize = dp(285f)
        distanceSinceLastPipe = 0f
    }

    fun flap() {
        if (gameOver) return
        started = true
        birdVelocity = flapVelocity
        SoundManager.playTap(context)
    }

    private fun gameLoop() {
        var lastTime = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            var dt = (now - lastTime) / 1_000_000_000f
            lastTime = now
            dt = min(dt, 0.033f) // clamp to avoid huge jumps after a stall

            if (started && !gameOver) update(dt)

            val canvas = holder.lockCanvas()
            if (canvas != null) {
                try {
                    renderFrame(canvas)
                } finally {
                    holder.unlockCanvasAndPost(canvas)
                }
            }
            Thread.sleep(4)
        }
    }

    private fun update(dt: Float) {
        birdVelocity = min(birdVelocity + gravity * dt, maxFall)
        birdY += birdVelocity * dt
        birdY = max(birdY, -birdRadius)

        groundOffset = (groundOffset - pipeSpeed * dt) % dp(40f)

        distanceSinceLastPipe += pipeSpeed * dt
        if (distanceSinceLastPipe >= pipeSpacing) {
            distanceSinceLastPipe = 0f
            spawnPipe()
        }

        val iterator = pipes.iterator()
        while (iterator.hasNext()) {
            val pipe = iterator.next()
            pipe.x -= pipeSpeed * dt

            if (!pipe.scored && pipe.x + pipeWidth < birdX) {
                pipe.scored = true
                score++
                coinsThisRun++
                GameData.addCoins(context, 1)
                GameData.addPipeCrossed(context, coinsThisRun)
                listener?.onScoreChanged(score, GameData.getCoins(context))
                SoundManager.playCoin(context)
                applyDifficulty()
            }

            if (pipe.x + pipeWidth < -dp(20f)) iterator.remove()
        }

        checkCollisions()
    }

    private fun applyDifficulty() {
        pipeSpeed = min(pipeSpeed + dp(2.5f), dp(340f))
        gapSize = max(gapSize - dp(1.6f), dp(175f))
    }

    private fun spawnPipe() {
        val h = height.toFloat()
        val margin = dp(90f)
        val gapCenter = Random.nextFloat() * (h - groundHeight - margin * 2) + margin
        pipes.add(Pipe(width.toFloat(), gapCenter, gapSize))
    }

    private fun checkCollisions() {
        val groundTop = height - groundHeight
        if (birdY + birdRadius >= groundTop) {
            birdY = groundTop - birdRadius
            endGame()
            return
        }
        for (pipe in pipes) {
            val birdLeft = birdX - birdRadius * 0.75f
            val birdRight = birdX + birdRadius * 0.75f
            val birdTop = birdY - birdRadius * 0.75f
            val birdBottom = birdY + birdRadius * 0.75f

            if (birdRight > pipe.x && birdLeft < pipe.x + pipeWidth) {
                val gapTop = pipe.gapCenter - pipe.gapSize / 2f
                val gapBottom = pipe.gapCenter + pipe.gapSize / 2f
                if (birdTop < gapTop || birdBottom > gapBottom) {
                    endGame()
                    return
                }
            }
        }
    }

    private fun endGame() {
        if (gameOver) return
        gameOver = true
        SoundManager.playGameOver(context)
        GameData.updateHighScore(context, score)
        GameData.addGamePlayed(context)
        listener?.onGameOver(score, coinsThisRun)
    }

    // ---------- drawing ----------

    private fun renderFrame(canvas: Canvas) {
        if (skyPaint.shader == null) {
            skyPaint.shader = LinearGradient(
                0f, 0f, 0f, height.toFloat(),
                intArrayOf(
                    Color.parseColor("#2E86C1"),
                    Color.parseColor("#4EC0E9"),
                    Color.parseColor("#EAF7FB")
                ),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), skyPaint)

        for (pipe in pipes) {
            val gapTop = pipe.gapCenter - pipe.gapSize / 2f
            val gapBottom = pipe.gapCenter + pipe.gapSize / 2f

            pipePaint.shader = LinearGradient(
                pipe.x, 0f, pipe.x + pipeWidth, 0f,
                intArrayOf(
                    Color.parseColor("#6B4423"),
                    Color.parseColor("#A97C50"),
                    Color.parseColor("#6B4423")
                ),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )

            canvas.drawRect(pipe.x, 0f, pipe.x + pipeWidth, gapTop, pipePaint)
            canvas.drawRect(pipe.x, gapBottom, pipe.x + pipeWidth, height - groundHeight, pipePaint)

            var wy = dp(28f)
            while (wy < gapTop - dp(10f)) {
                canvas.drawLine(pipe.x + dp(5f), wy, pipe.x + pipeWidth - dp(5f), wy, woodGrainPaint)
                wy += dp(36f)
            }
            wy = gapBottom + dp(28f)
            while (wy < height - groundHeight - dp(10f)) {
                canvas.drawLine(pipe.x + dp(5f), wy, pipe.x + pipeWidth - dp(5f), wy, woodGrainPaint)
                wy += dp(36f)
            }

            drawLogCap(canvas, pipe.x, gapTop, true)
            drawLogCap(canvas, pipe.x, gapBottom, false)
        }

        drawGround(canvas)
        drawBird(canvas)

        canvas.drawText(score.toString(), width / 2f, dp(70f), scorePaint)
    }

    private fun drawLogCap(canvas: Canvas, pipeX: Float, edgeY: Float, hangsDown: Boolean) {
        val overhang = dp(6f)
        val capH = dp(16f)
        val top = if (hangsDown) edgeY else edgeY - capH
        val bottom = if (hangsDown) edgeY + capH else edgeY
        val rect = RectF(pipeX - overhang, top, pipeX + pipeWidth + overhang, bottom)
        canvas.drawRect(rect, woodCapPaint)
        canvas.drawRect(rect, woodCapEdgePaint)
        val cx = rect.centerX()
        val cy = rect.centerY()
        canvas.drawOval(RectF(cx - rect.width() * 0.32f, cy - dp(5f), cx + rect.width() * 0.32f, cy + dp(5f)), woodRingPaint)
        canvas.drawOval(RectF(cx - rect.width() * 0.18f, cy - dp(3f), cx + rect.width() * 0.18f, cy + dp(3f)), woodRingPaint)
    }

    private fun drawGround(canvas: Canvas) {
        val groundTop = height - groundHeight
        val grassHeight = dp(18f)

        canvas.drawRect(0f, groundTop + grassHeight, width.toFloat(), height.toFloat(), dirtPaint)
        canvas.drawRect(0f, groundTop + grassHeight + dp(16f), width.toFloat(), groundTop + grassHeight + dp(18f), soilLinePaint)
        canvas.drawRect(0f, groundTop + grassHeight + dp(36f), width.toFloat(), groundTop + grassHeight + dp(38f), soilLinePaint)

        val bladeWidth = dp(16f)
        val phase = ((groundOffset % bladeWidth) + bladeWidth) % bladeWidth
        var gx = -phase
        val path = Path()
        path.moveTo(gx, groundTop + grassHeight)
        var tipUp = true
        while (gx <= width + bladeWidth) {
            val y = if (tipUp) groundTop else groundTop + grassHeight * 0.45f
            path.lineTo(gx, y)
            gx += bladeWidth / 2f
            tipUp = !tipUp
        }
        path.lineTo(width.toFloat(), groundTop + grassHeight)
        path.close()
        canvas.drawPath(path, grassPaint)
        canvas.drawRect(0f, groundTop + grassHeight - dp(4f), width.toFloat(), groundTop + grassHeight, grassShadePaint)
    }

    private fun drawBird(canvas: Canvas) {
        val angle = (birdVelocity / maxFall * 60f).coerceIn(-30f, 75f)
        val size = (birdRadius * 2.2f).toInt()
        val left = (birdX - size / 2f).toInt()
        val top = (birdY - size / 2f).toInt()

        canvas.save()
        canvas.rotate(angle, birdX, birdY)
        birdDrawable?.let {
            it.setBounds(left, top, left + size, top + size)
            it.draw(canvas)
        }
        faceAccessory?.let {
            it.setBounds(left, top, left + size, top + size)
            it.draw(canvas)
        }
        headAccessory?.let {
            it.setBounds(left, top, left + size, top + size)
            it.draw(canvas)
        }
        canvas.restore()
    }
}
