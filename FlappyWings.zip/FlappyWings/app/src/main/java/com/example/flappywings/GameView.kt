package com.example.flappywings

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import androidx.core.content.ContextCompat
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

interface GameListener {
    fun onGameOver(score: Int, coinsEarned: Int)
    fun onScoreChanged(score: Int, coins: Int)
}

class GameView(context: Context, attrs: AttributeSet? = null) :
    SurfaceView(context, attrs), SurfaceHolder.Callback {

    private var thread: Thread? = null
    @Volatile private var running = false

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    // ---- physics ----
    private var birdY = 0f
    private var birdVelocity = 0f
    private val gravity = dp(1500f)
    private val flapVelocity = -dp(520f)
    private val maxFall = dp(900f)
    private var birdX = 0f
    private val birdRadius = dp(20f)

    // ---- pipes ----
    data class Pipe(var x: Float, val gapCenter: Float, val gapSize: Float, var scored: Boolean = false)
    private val pipes = mutableListOf<Pipe>()
    private val pipeWidth = dp(76f)
    private var pipeSpeed = dp(150f)
    private var gapSize = dp(285f)
    private var distanceSinceLastPipe = 0f
    private val pipeSpacing = dp(300f)

    private var groundHeight = dp(60f)
    private var groundOffset = 0f

    private var score = 0
    private var coinsThisRun = 0
    private var gameOver = false
    private var started = false

    var listener: GameListener? = null

    // ---- drawables ----
    private var birdDrawable: Drawable? = null
    private var headAccessory: Drawable? = null
    private var faceAccessory: Drawable? = null

    private val skyPaint = Paint()
    private val groundPaint = Paint().apply { color = ContextCompat.getColor(context, R.color.ground) }
    private val pipePaint = Paint().apply { color = ContextCompat.getColor(context, R.color.pipe) }
    private val pipeEdgePaint = Paint().apply {
        color = Color.argb(60, 0, 0, 0); style = Paint.Style.STROKE; strokeWidth = dp(3f)
    }
    private val scorePaint = Paint().apply {
        color = Color.WHITE; textSize = dp(36f); textAlign = Paint.Align.CENTER
        setShadowLayer(6f, 0f, 3f, Color.BLACK); isFakeBoldText = true
    }

    init {
        holder.addCallback(this)
        isFocusable = true
        loadBirdAppearance()
    }

    fun loadBirdAppearance() {
        val birdId = GameData.getSelectedBird(context)
        val resId = resources.getIdentifier(birdId, "drawable", context.packageName)
        birdDrawable = if (resId != 0) ContextCompat.getDrawable(context, resId) else null

        val head = GameData.getEquipped(context, "head")
        headAccessory = if (head.isNotBlank()) {
            val id = resources.getIdentifier(head, "drawable", context.packageName)
            if (id != 0) ContextCompat.getDrawable(context, id) else null
        } else null

        val face = GameData.getEquipped(context, "face")
        faceAccessory = if (face.isNotBlank()) {
            val id = resources.getIdentifier(face, "drawable", context.packageName)
            if (id != 0) ContextCompat.getDrawable(context, id) else null
        } else null
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        resetGame()
        running = true
        thread = Thread { gameLoop() }.also { it.start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        thread?.join()
        thread = null
    }

    fun restart() {
        resetGame()
    }

    fun continueAfterAd() {
        gameOver = false
        pipes.clear()
        distanceSinceLastPipe = 0f
        birdY = height * 0.4f
        birdVelocity = 0f
    }

    private fun resetGame() {
        birdX = width * 0.28f
        birdY = height * 0.4f
        birdVelocity = 0f
        pipes.clear()
        score = 0
        coinsThisRun = 0
        gameOver = false
        started = false
        pipeSpeed = dp(150f)
        gapSize = dp(285f)
        distanceSinceLastPipe = 0f
    }

    fun flap() {
        if (gameOver) return
        started = true
        birdVelocity = flapVelocity
        SoundManager.playTap(context)
    }

    private fun gameLoop() {
        var lastTime = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            var dt = (now - lastTime) / 1_000_000_000f
            lastTime = now
            dt = min(dt, 0.033f) // clamp to avoid huge jumps after a stall

            if (started && !gameOver) update(dt)

            val canvas = holder.lockCanvas()
            if (canvas != null) {
                try {
                    renderFrame(canvas)
                } finally {
                    holder.unlockCanvasAndPost(canvas)
                }
            }
            Thread.sleep(4)
        }
    }

    private fun update(dt: Float) {
        birdVelocity = min(birdVelocity + gravity * dt, maxFall)
        birdY += birdVelocity * dt
        birdY = max(birdY, -birdRadius)

        groundOffset = (groundOffset - pipeSpeed * dt) % dp(40f)

        distanceSinceLastPipe += pipeSpeed * dt
        if (distanceSinceLastPipe >= pipeSpacing) {
            distanceSinceLastPipe = 0f
            spawnPipe()
        }

        val iterator = pipes.iterator()
        while (iterator.hasNext()) {
            val pipe = iterator.next()
            pipe.x -= pipeSpeed * dt

            if (!pipe.scored && pipe.x + pipeWidth < birdX) {
                pipe.scored = true
                score++
                coinsThisRun++
                GameData.addCoins(context, 1)
                GameData.addPipeCrossed(context, coinsThisRun)
                listener?.onScoreChanged(score, GameData.getCoins(context))
                SoundManager.playCoin(context)
                applyDifficulty()
            }

            if (pipe.x + pipeWidth < -dp(20f)) iterator.remove()
        }

        checkCollisions()
    }

    private fun applyDifficulty() {
        pipeSpeed = min(pipeSpeed + dp(2.5f), dp(340f))
        gapSize = max(gapSize - dp(1.6f), dp(175f))
    }

    private fun spawnPipe() {
        val h = height.toFloat()
        val margin = dp(90f)
        val gapCenter = Random.nextFloat() * (h - groundHeight - margin * 2) + margin
        pipes.add(Pipe(width.toFloat(), gapCenter, gapSize))
    }

    private fun checkCollisions() {
        val groundTop = height - groundHeight
        if (birdY + birdRadius >= groundTop) {
            birdY = groundTop - birdRadius
            endGame()
            return
        }
        for (pipe in pipes) {
            val birdLeft = birdX - birdRadius * 0.75f
            val birdRight = birdX + birdRadius * 0.75f
            val birdTop = birdY - birdRadius * 0.75f
            val birdBottom = birdY + birdRadius * 0.75f

            if (birdRight > pipe.x && birdLeft < pipe.x + pipeWidth) {
                val gapTop = pipe.gapCenter - pipe.gapSize / 2f
                val gapBottom = pipe.gapCenter + pipe.gapSize / 2f
                if (birdTop < gapTop || birdBottom > gapBottom) {
                    endGame()
                    return
                }
            }
        }
    }

    private fun endGame() {
        if (gameOver) return
        gameOver = true
        SoundManager.playGameOver(context)
        GameData.updateHighScore(context, score)
        GameData.addGamePlayed(context)
        listener?.onGameOver(score, coinsThisRun)
    }

    // ---------- drawing ----------

    private fun renderFrame(canvas: Canvas) {
        if (skyPaint.shader == null) {
            skyPaint.shader = LinearGradient(
                0f, 0f, 0f, height.toFloat(),
                ContextCompat.getColor(context, R.color.sky_top),
                ContextCompat.getColor(context, R.color.sky_bottom),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), skyPaint)

        for (pipe in pipes) {
            val gapTop = pipe.gapCenter - pipe.gapSize / 2f
            val gapBottom = pipe.gapCenter + pipe.gapSize / 2f
            canvas.drawRect(pipe.x, 0f, pipe.x + pipeWidth, gapTop, pipePaint)
            canvas.drawRect(pipe.x, gapBottom, pipe.x + pipeWidth, height - groundHeight, pipePaint)
            canvas.drawRect(pipe.x, 0f, pipe.x + pipeWidth, gapTop, pipeEdgePaint)
            canvas.drawRect(pipe.x, gapBottom, pipe.x + pipeWidth, height - groundHeight, pipeEdgePaint)
        }

        // ground
        canvas.drawRect(0f, height - groundHeight, width.toFloat(), height.toFloat(), groundPaint)
        val stripePaint = Paint().apply { color = Color.argb(50, 0, 0, 0) }
        var gx = groundOffset
        while (gx < width) {
            canvas.drawRect(gx, height - groundHeight, gx + dp(20f), height.toFloat(), stripePaint)
            gx += dp(40f)
        }

        drawBird(canvas)

        canvas.drawText(score.toString(), width / 2f, dp(70f), scorePaint)
    }

    private fun drawBird(canvas: Canvas) {
        val angle = (birdVelocity / maxFall * 60f).coerceIn(-30f, 75f)
        val size = (birdRadius * 2.2f).toInt()
        val left = (birdX - size / 2f).toInt()
        val top = (birdY - size / 2f).toInt()

        canvas.save()
        canvas.rotate(angle, birdX, birdY)
        birdDrawable?.let {
            it.setBounds(left, top, left + size, top + size)
            it.draw(canvas)
        }
        faceAccessory?.let {
            it.setBounds(left, top, left + size, top + size)
            it.draw(canvas)
        }
        headAccessory?.let {
            it.setBounds(left, top, left + size, top + size)
            it.draw(canvas)
        }
        canvas.restore()
    }
}
