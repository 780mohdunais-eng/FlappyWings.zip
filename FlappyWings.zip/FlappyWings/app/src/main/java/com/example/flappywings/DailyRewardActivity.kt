package com.example.flappywings

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class DailyRewardActivity : AppCompatActivity() {

    private lateinit var wheel: SpinWheelView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_daily_reward)

        wheel = findViewById(R.id.wheel)
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnSpin).setOnClickListener { doSpin() }

        refresh()
    }

    private fun refresh() {
        val canSpin = GameData.canSpinToday(this)
        findViewById<Button>(R.id.btnSpin).isEnabled = canSpin
        findViewById<TextView>(R.id.statusText).text = if (canSpin) {
            "Aaj ka free spin ready hai!"
        } else {
            val hrs = GameData.spinTimeRemainingMs(this) / 3600000
            val mins = (GameData.spinTimeRemainingMs(this) % 3600000) / 60000
            "Agla spin ${hrs}h ${mins}m me milega"
        }
    }

    private fun doSpin() {
        findViewById<Button>(R.id.btnSpin).isEnabled = false
        val targetIndex = Random.nextInt(wheel.segments.size)
        wheel.spinTo(targetIndex) {
            applyReward(targetIndex)
            GameData.recordSpin(this)
            refresh()
        }
    }

    private fun applyReward(index: Int) {
        val segment = wheel.segments[index]
        when (segment.label) {
            "50" -> { GameData.addCoins(this, 50); toast("+50 Coins!") }
            "100" -> { GameData.addCoins(this, 100); toast("+100 Coins!") }
            "200" -> { GameData.addCoins(this, 200); toast("+200 Coins!") }
            "500" -> { GameData.addCoins(this, 500); toast("Jackpot! +500 Coins!") }
            "Glasses" -> {
                if (GameData.ownsItem(this, "item_glasses")) {
                    GameData.addCoins(this, 150); toast("Glasses already hain — +150 Coins mile")
                } else {
                    GameData.unlockItem(this, "item_glasses"); toast("Glasses mil gaye!")
                }
            }
            "Hat" -> {
                if (GameData.ownsItem(this, "item_hat")) {
                    GameData.addCoins(this, 200); toast("Hat already hai — +200 Coins mile")
                } else {
                    GameData.unlockItem(this, "item_hat"); toast("Hat mil gaya!")
                }
            }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
