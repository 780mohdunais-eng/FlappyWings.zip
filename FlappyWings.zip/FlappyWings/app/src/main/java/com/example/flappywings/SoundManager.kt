package com.example.flappywings

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.sin

object SoundManager {
    private const val SAMPLE_RATE = 44100

    private fun generateTone(freqStart: Double, freqEnd: Double, durationMs: Int): ByteArray {
        val numSamples = (SAMPLE_RATE * durationMs / 1000.0).toInt()
        val samples = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / numSamples
            val freq = freqStart + (freqEnd - freqStart) * t
            val angle = 2.0 * PI * i * freq / SAMPLE_RATE
            val fade = if (i > numSamples - 300) (numSamples - i) / 300.0 else 1.0
            samples[i] = (sin(angle) * Short.MAX_VALUE * 0.5 * fade).toInt().toShort()
        }
        val bytes = ByteArray(numSamples * 2)
        for (i in samples.indices) {
            bytes[i * 2] = (samples[i].toInt() and 0xFF).toByte()
            bytes[i * 2 + 1] = ((samples[i].toInt() shr 8) and 0xFF).toByte()
        }
        return bytes
    }

    private var tapSound: ByteArray? = null
    private var coinSound: ByteArray? = null
    private var overSound: ByteArray? = null

    private fun ensureInit() {
        if (tapSound == null) tapSound = generateTone(500.0, 750.0, 70)
        if (coinSound == null) coinSound = generateTone(750.0, 1300.0, 130)
        if (overSound == null) overSound = generateTone(420.0, 140.0, 420)
    }

    private fun play(context: Context, data: ByteArray) {
        if (!GameData.isSoundOn(context)) return
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            val track = AudioTrack(
                attrs, format, data.size, AudioTrack.MODE_STATIC,
                AudioManager.AUDIO_SESSION_ID_GENERATE
            )
            track.write(data, 0, data.size)
            track.setNotificationMarkerPosition(data.size / 2)
            track.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(t: AudioTrack?) { runCatching { t?.release() } }
                override fun onPeriodicNotification(t: AudioTrack?) {}
            })
            track.play()
        } catch (e: Exception) {
            // audio hardware busy/unavailable - safe to skip, gameplay isn't affected
        }
    }

    fun playTap(context: Context) { ensureInit(); play(context, tapSound!!) }
    fun playCoin(context: Context) { ensureInit(); play(context, coinSound!!) }
    fun playGameOver(context: Context) { ensureInit(); play(context, overSound!!) }
}
